//
//  IoTPasswordField.h
//  IoTProcessModel
//
//  Created by xpg on 14/12/26.
//  Copyright (c) 2014年 xpg. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IoTPasswordField : UITextField

@end

void initPasswordField();
