/**
 * IoTScanResult.m
 *
 * Copyright (c) 2014~2015 Xtreme Programming Group, Inc.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

#import "IoTScanResult.h"
#import "ZBarSDK.h"
#import "IoTWifiUtil.h"
#import "IoTAddDevice.h"
#import "IoTConfigure.h"
#import "IoTDisconnected.h"
#import "DirectLink.h"

@interface IoTScanResult () <ZBarReaderDelegate, UITextFieldDelegate>
{
    IoTDisconnected *disconnectCtrl;
    
    NSTimer *waitTimer;
    BOOL isTure;
    int flag;
    
    //用于返回页面时重置
    NSInteger resetTimeout;
}

@property (weak, nonatomic) IBOutlet UIView *modelView;
@property (weak, nonatomic) IBOutlet UIView *timeView;

@property (weak, nonatomic) IBOutlet UITextField *WiFiName2;
@property (weak, nonatomic) IBOutlet IoTPasswordField *textPass;
@property (weak, nonatomic) IBOutlet UILabel *textTime;

@property (strong, nonatomic) NSString *ssid;
@property (strong, nonatomic) NSArray *devices;
@property (assign, nonatomic) NSInteger timeout;
@property (strong, nonatomic) XPGWifiDevice *device;
@property (strong, nonatomic) NSString *productkey;

@end

@implementation IoTScanResult


- (id)initWithDevices:(NSArray *)devices
{
    self = [super initWithNibName:nil bundle:[IoTProcessModel resourceBundle]];
    if(self)
    {
        self.devices = devices;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.timeView.alpha = 0;
    
    [self didBecomeActive];
    
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [XPGWifiSDK sharedInstance].delegate = self;
    isTure = NO;

    //加个通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onResume) name:UIApplicationDidBecomeActiveNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didBecomeActive) name:UIApplicationDidBecomeActiveNotification object:nil];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    //防止弹出的时候把delegate赋值
    [XPGWifiSDK sharedInstance].delegate = nil;
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIApplicationDidBecomeActiveNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIApplicationDidBecomeActiveNotification object:nil];
    
}

- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
    self.textPass.text = nil;
//    [self stop];
    [waitTimer invalidate];
    waitTimer = nil;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)onTop:(id)sender {
    [self.textPass resignFirstResponder];
}

- (IBAction)onScanQRCode:(id)sender {

    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)onConfigure:(id)sender {
    if([IoTWifiUtil isConnectedWifi])
    {
        int timeout = XPG_SOFTAP_TIMEOUT;
        self.timeView.alpha = 1;
        
//        if (self.modelBtn.selected == YES) {
//            [[DirectLink sharedInstance] startWithSSID:self.wifiName.text password:self.textPass.text];
//            
//        }else if (self.modelBtn2.selected == YES){
//            [[XPGWifiSDK sharedInstance] setDeviceWifi:self.WiFiName2.text key:self.textPass.text mode:XPGWifiSDKSoftAPMode softAPSSIDPrefix:@"XPG-GAgent" timeout:timeout];
//        }
        isTure = YES;
        flag ++;
        [[XPGWifiSDK sharedInstance] setDeviceWifi:self.WiFiName2.text key:self.textPass.text mode:XPGWifiSDKSoftAPMode softAPSSIDPrefix:@"XPG-GAgent" timeout:timeout];
        resetTimeout = timeout;
        self.timeout = resetTimeout;
        [waitTimer invalidate];
        waitTimer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(onTimer) userInfo:nil repeats:YES];
    }
//    else
//    {
//        disconnectCtrl = [[IoTDisconnected alloc] init];
//        [disconnectCtrl show:YES];
//    }
}

//-(void)stop
//{
//    [waitTimer invalidate];
//    waitTimer = nil;
//    [[DirectLink sharedInstance] stop];
//}

- (void)onTimer
{
    if(self.timeout == 0)
    {
        [waitTimer invalidate];
        waitTimer = nil;
        
        [self configureFailed];
        return;
    }
    self.timeout --;
    self.textTime.text = [NSString stringWithFormat:@"%@", @(self.timeout)];
}

- (void)didBecomeActive
{
    self.ssid = [[IoTWifiUtil SSIDInfo] valueForKey:@"SSID"];
    if(nil == self.ssid)
    {
        self.ssid = @"";
    }
}

- (void)onResume {
    [disconnectCtrl hide:YES];
}

#pragma mark - XPGWifiSDK delegate
- (void)XPGWifiSDK:(XPGWifiSDK *)wifiSDK didBindDevice:(NSString *)did error:(NSNumber *)error errorMessage:(NSString *)errorMessage
{
    //退出界面并回调
    [ProcessModel.hud hide:YES];
    
}

- (void)XPGWifiSDK:(XPGWifiSDK *)wifiSDK didSetDeviceWifi:(XPGWifiDevice *)device result:(int)result{
    NSLog(@"result:%d",result);
    if(result == 0 && ([device.productKey isEqual: @"da9471bea92540da94b4e3fd14f63c68"]))
    {
        //配置成功
        if (isTure == YES && flag == 1) {
            [self configureSucceed];
        }
    }
    else
    {
        if (isTure == YES ) {
            [self configureFailed];
            isTure = NO;
        }
    }
}

- (void)configureSucceed{
    [[[UIAlertView alloc] initWithTitle:@"提示" message:@"配置成功" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil] show];
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)configureFailed{
    [[[UIAlertView alloc] initWithTitle:@"提示" message:@"配置失败" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil] show];
    self.timeView.alpha = 0;
}

@end
