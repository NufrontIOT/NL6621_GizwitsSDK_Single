//
//  IoTDisconnected.h
//  IoTProcessModel
//
//  Created by xpg on 14/12/23.
//  Copyright (c) 2014年 xpg. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IoTDisconnected : UIViewController

- (void)show:(BOOL)animated;
- (void)hide:(BOOL)animated;

@end
