//
//  DirectLink.h
//  DirectLink
//
//  Created by GeHaitong on 15/4/21.
//  Copyright (c) 2015年 xpg. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DirectLink : NSObject

@property (nonatomic, assign, readonly) BOOL isStarted;

- (instancetype)init NS_UNAVAILABLE;

+ (instancetype)sharedInstance;

- (void)startWithSSID:(NSString *)ssid password:(NSString *)password;
- (void)stop;

@end
