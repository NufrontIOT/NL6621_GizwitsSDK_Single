//
//  IoTDeviceCollectItem.h
//  SmartSocket-Debug
//
//  Created by GeHaitong on 15/3/16.
//  Copyright (c) 2015年 xpg. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IoTDeviceCollectItem : UIView

- (id)initWithIndexPath:(NSIndexPath *)indexPath isSelectec:(BOOL)isSelected;

@end
